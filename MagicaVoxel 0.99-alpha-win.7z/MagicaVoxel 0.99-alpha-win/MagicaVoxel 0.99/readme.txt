[MagicaVoxel : 8-bit Voxel Editor & Renderer]
================================
date    : 11/23/2017

version : 0.99a

os      : Win32, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
